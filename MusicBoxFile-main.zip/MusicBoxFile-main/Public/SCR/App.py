# This is the main script that runs the app

# Import the Flask framework
from flask import Flask, render_template

# Import the routes from the app package
from app.routes import artist, event, user, error

# Create an app instance
app = Flask(__name__)

# Register the routes for the app views
app.register_blueprint(artist.bp)
app.register_blueprint(event.bp)
app.register_blueprint(user.bp)
app.register_blueprint(error.bp)

# Register the route for the home page
@app.route("/")
def home():
    # Render the index.html template
    return render_template("index.html")

# Start the app server
if __name__ == "__main__":
    app.run()
