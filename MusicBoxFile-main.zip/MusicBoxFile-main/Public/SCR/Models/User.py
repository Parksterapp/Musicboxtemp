# Import SQLAlchemy and other modules
from sqlalchemy import Column, Integer, String, DateTime, Enum, ForeignKey
from sqlalchemy.ext.declarative import declarative_base
from sqlalchemy.orm import relationship
# Create a base class for the data model
Base = declarative_base()
# Define the user entity as a subclass of the base class
class User (Base):
  # Specify the table name for the user entity
  __tablename__ = 'user'

  # Define the attributes of the user entity
  id = Column (Integer, primary_key=True) # The unique identifier of the user
  username = Column (String (100), nullable=False, unique=True) # The username of the user
  email = Column (String (100), nullable=False, unique=True) # The email of the user
  password = Column (String (100), nullable=False) # The password of the user
  subscription = Column (Enum ('Basic', 'Premium', 'VIP', name='subscription'), default='Basic') # The subscription plan of the user
  rating = Column (Integer, default=0) # The rating of the user, from 0 to 5
  created_at = Column (DateTime, default=datetime.datetime.utcnow) # The date and time when the user was created
  updated_at = Column (DateTime, default=datetime.datetime.utcnow, onupdate=datetime.datetime.utcnow) # The date and time when the user was updated
  # Define the foreign key relationship with the event entity
  event_id = Column (Integer, ForeignKey ('event.id')) # The id of the event that the user booked or attended
  event = relationship ('Event', backref='users') # The event object that the user booked or attended
# Import SQLAlchemy and other modules
from sqlalchemy import create_engine
from sqlalchemy.orm import sessionmaker

# Create a database engine with the connection string of your database
# For example, if you are using SQLite, you can use 'sqlite:///musicbox.db' as the connection string
engine = create_engine ('sqlite:///musicbox.db')

# Create a session class that binds to the database engine
Session = sessionmaker (bind=engine)

# Instantiate a session object from the session class
session = Session()

# Use the session object to perform operations on the data model
# For example, to add a new user to the database, you can do:
new_user = User (username='jane_doe', email='jane.doe@example.com', password='password123', subscription='Premium')
session.add (new_user)
session.commit()

# To query all the users from the database, you can do:
users = session.query (User).all()
for user in users:
  print (user.username, user.email, user.subscription, user.rating, user.event.title)

# To update an existing user in the database, you can do:
user = session.query (User).filter_by (username='jane_doe').first()
user.password = 'new_password'
session.commit()

# To delete a user from the database, you can do:
user = session.query (User).filter_by (username='jane_doe').first()
session.delete (user)
session.commit()

# To close the session, you can do:
session.close()
  
